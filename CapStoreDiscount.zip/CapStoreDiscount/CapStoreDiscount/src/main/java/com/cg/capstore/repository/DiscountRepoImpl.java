package com.cg.capstore.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Product;

@Repository()
public class DiscountRepoImpl implements DiscountRepo {
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Product applyDiscount(int prod_id) {
		Product product = entityManager.find(Product.class, prod_id);
		double discount = product.getProdDiscount();
		if (discount == 0)
			System.err.println("Sorry! There is no discount available now on this Product");
		else {
			double price = product.getPrice();
			product.setPrice(price - discount);
		}
		return product;
	}

}
