package com.cg.capstore.CapStoreDiscount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")
@EntityScan("com.cg.capstore.beans")
public class CapStoreDiscountApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreDiscountApplication.class, args);
	}

}

