package com.cg.capstore.service;

import com.cg.capstore.beans.Product;

public interface DiscountService {
	Product applyDiscount(int prodId);
}
